# gesture_recognition
Hand gesture recognition using Statistical machine learning
